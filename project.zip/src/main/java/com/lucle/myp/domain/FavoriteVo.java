package com.lucle.myp.domain;

import lombok.Data;

@Data
public class FavoriteVo {
	private Long fno;
	private String id;
	private Long bno;
	private String favoriteDate;
}
