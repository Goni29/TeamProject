package com.lucle.myp.domain;

public class GroupBuyingVo {

	private Long gno;
	private String title;
	private String content;
	private String regidate;
	private String goaldate;
	private Long goaltarget;
	private Long num;
}
