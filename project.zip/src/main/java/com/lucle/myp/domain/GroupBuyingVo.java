package com.lucle.myp.domain;

import lombok.Data;

@Data
public class GroupBuyingVo {

	private Long gno;
	private String title;
	private String content;
	private String regidate;
	private String goaldate;
	private Long goaltarget;
	private Long num;
	private Long personnum;
}
